from django.db import models

class Encoder(models.Model):
    name = models.CharField(max_length=10)
    path = models.FilePathField(path='/usr/bin/encoders/')
    inputflag = models.CharField(max_length=10, blank=True, null=True)
    outputflag = models.CharField(max_length=10, blank=True, null=True)

    def __unicode__(self):
        return "encoder: %s" % (self.name)   
    
class Extension(models.Model):
    name = models.CharField(max_length=5)
    
    def __unicode__(self):
        return ".%s" % (self.name)

class Job(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=100, null=True, blank=True)
    created_by = models.CharField(max_length=30)
    modified_by = models.CharField(max_length=30)
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now = True)
    encoder = models.ForeignKey(Encoder)
    options = models.CharField(max_length=240)
    extension = models.ForeignKey(Extension)
    
    def __unicode__(self):
        return "%s" % (self.name)
    
    def getDetails(self):
        details = {}
        for name in self.__dict__:
            if not name.startswith('_'):
                details[name] =  self.__dict__[name]
        return details

class Joblist(models.Model):
    name = models.CharField(max_length=30)
    description = models.CharField(max_length=100, null=True, blank=True)
    created_by = models.CharField(max_length=30)
    modified_by = models.CharField(max_length=30)
    created_on = models.DateTimeField(auto_now_add=True)
    modified_on = models.DateTimeField(auto_now = True)
    job = models.ManyToManyField(Job)

    def __unicode__(self):
        return "%s" % (self.name)
    
    def getDetails(self):
        details = {}
        for name in self.__dict__:
            if not name.startswith('_'):
                details[name] =  self.__dict__[name]
        return details
    
class Task(models.Model):
    NOTIFICATION_CHOICES = ((1,'User'), (2,'Group'))
    joblist = models.ForeignKey(Joblist)
    schedule = models.DateTimeField()
    owner = models.CharField(max_length=30)
    state = models.CharField(max_length=10)
    source_file = models.FileField(upload_to="videos/%Y%m%d_%H%M%S")
    notify = models.IntegerField(choices=NOTIFICATION_CHOICES,null=True, blank=True)
    
    def getDetails(self):
        details = {}
        for name in self.__dict__:
            if not name.startswith('_'):
                details[name] =  self.__dict__[name]
        return details

class TaskHistory(models.Model):
    joblist = models.CharField(max_length=30)
    owner = models.CharField(max_length=30)
    state = models.CharField(max_length=10)
    starttime = models.DateTimeField()
    endtime = models.DateTimeField()
    outputdir = models.CharField(max_length=20)
    log = models.TextField(null=True, blank=True)
    

    
    
