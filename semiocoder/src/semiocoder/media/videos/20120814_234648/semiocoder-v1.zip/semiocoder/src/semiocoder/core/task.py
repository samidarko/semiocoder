# -*- coding: utf-8 -*-
import os
import subprocess
from time import sleep
from datetime import datetime
from semiocoder.encoder.models import Task, TaskHistory
from semiocoder.core.notification import notify

def launchTask(taskId):
    task = Task.objects.get(pk=taskId)
    th = TaskHistory(joblist = task.joblist.name, owner = task.owner, starttime = datetime.now(), outputdir = task.source_file.url[15:30])
    #fout = open("/tmp/"+datetime.now().strftime('%Y-%m-%d_%H:%M:%S')+task.joblist.name+".log", "w")
    args = []
    log = ""
    ret_code = ret = 0
    #os.chdir(os.path.dirname(__file__))
    for job in task.joblist.job.select_related():
        log += "#### Log %s ####################\n\n" % (job.name)
        args.append(job.encoder.name)
        if job.encoder.inputflag: args.append(job.encoder.inputflag)
        args.append(task.source_file.url.replace("/static", "media"))
        args.extend(job.options.split())
        if job.encoder.outputflag: args.append(job.encoder.outputflag)
        filename = task.source_file.url[:31].replace("/static", "media")+datetime.now().strftime("%H%M%S")+'-'
        filename += os.path.splitext(os.path.basename(task.source_file.url))[0]+'-'+job.name+'.'+job.extension.name
        args.append(filename)
        # traitement de la commande
        cmdout = cmderr = ""
        cmdp = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        cmdout,cmderr =  cmdp.communicate()
        ret = cmdp.wait()
        log += cmdout
        if cmderr: log += "<br>Error log :<br>" + cmderr
        log += "<br>"
        if ret != 0: ret_code = ret
        args = []
        sleep(1)
    if ret_code == 0:
        th.state = "complete"
    else:
        th.state = "uncomplete"
    th.log = log
    th.endtime = datetime.now()
    th.save()
    if task.notify:
        notify(level=task.notify, history=th.id)
    task.source_file.delete()
    task.delete()
    

