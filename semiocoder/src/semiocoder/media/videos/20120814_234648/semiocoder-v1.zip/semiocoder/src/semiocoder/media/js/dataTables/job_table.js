
$(document).ready(function() {
	$('#job_table').dataTable( {
		"bProcessing": true,
		"bServerSide": true,
		"sAjaxSource": "/job/all_data",
	} );
} );

