# -*- coding: utf-8 -*-
#import setenv
from datetime import datetime
from semiocoder.encoder.models import Task
from semiocoder.core.task import launchTask


def scheduledCheck():
    task = Task.objects.filter(schedule__lte=datetime.now()).order_by('schedule')
    if task:
        if task[0].state != "running":
            task[0].state="running"
            task[0].save()
            launchTask(task[0].id)
        if len(task) > 1:
            for index, t in enumerate(task):
                if index > 1:
                    if t.state != "pending":
                        t.state = "pending"
                        task.save()
        
            
            
if __name__ == "__main__":
#    from django.core.management import execute_manager
#    import settings
#    execute_manager(settings)
#    sys.path.append(os.path.dirname(os.getcwd()))
#    sys.path.append(os.path.dirname(os.getcwd())+'/encoder')
    scheduledCheck()
