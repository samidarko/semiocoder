import json
#import datetime
#from django.contrib.auth.models import User
from semiocoder.settings import LOGIN_URL
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponse, HttpResponseRedirect
from django.template.context import RequestContext
from django.shortcuts import render_to_response
from django.db.models import Q
from semiocoder.encoder.models import Job
from semiocoder.encoder.forms import JobForm

columns = [
    "name",
    "description",
    "created_by",
    "modified_by",
    "created_on",
    "modified_on",
    "encoder",
    "options",
    "extension"
]

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def list(request):
    #job_list = Job.objects.all()
    #data = { 'job_list' : "", }
    return render_to_response("encoder/job.html", context_instance=RequestContext(request))

def details(request, jobId):
    data = { 'element': 'job', 'id' : jobId, 'details' : getJobDetails(jobId), }
    return render_to_response("encoder/encoding_details.html", data, context_instance=RequestContext(request))

def all_data(request):
    
    try:
        iDisplayStart = int(request.GET["iDisplayStart"])
        iDisplayLength = int(request.GET["iDisplayLength"])
        sSearch = request.GET["sSearch"]
        sEcho = int(request.GET["sEcho"])
        try:
            column = int(request.GET["iSortCol_0"])
            ascending = (request.GET["sSortDir_0"] == "asc")
        except:
            column = 0
            ascending = True
    except:
        pass

    total_jobs, filtered_jobs, jobs = getJobs(first_id=iDisplayStart, 
                         last_id=iDisplayStart + iDisplayLength - 1,
                         search_str=sSearch,
                         sort_by=columns[column], 
                         asc=ascending)

    json_data = {
        "sEcho" : sEcho,
        "iTotalRecords" : total_jobs,
        "iTotalDisplayRecords" : filtered_jobs,
        "aaData" : jobs
    }

    return HttpResponse(json.dumps(json_data))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def form(request, jobId):
    if jobId == '0':
        form = JobForm()
    elif jobId > '0':
        j = Job.objects.get(pk=jobId)
        form = JobForm(instance=j)
    data = { 'element': 'job', 'form': form, 'formid': jobId }
    return render_to_response('encoder/encoding_form.html', data, context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def submit(request):
    if request.method == 'POST':
        jobId = int(request.POST["formid"])
        username = request.user.username
        if jobId == 0:
            j = Job(created_by=username, modified_by=username)
            form = JobForm(request.POST, instance=j)
        elif jobId > 0:
            j = Job.objects.get(pk=jobId)
            j.modified_by = username
            form = JobForm(request.POST, instance=j)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/job')
        else:
                data = { 'element': 'job', 'form': form, 'formid': jobId }
                return render_to_response('encoder/encoding_form.html', data, context_instance=RequestContext(request))    
    else:
        return HttpResponseRedirect('/job') 

def delete(request, jobId):
    if request.method == 'POST':
        jobId = int(request.POST["formid"])
        if request.POST["confirm"] == "yes":
            j = Job.objects.get(pk=jobId)
            j.delete()
        return HttpResponseRedirect('/job')
    else:
        j = Job.objects.get(pk=jobId)
        data = { 'element': 'job', 'name': j.name, 'formid': jobId }
        return render_to_response('encoder/delete_confirmation.html', data, context_instance=RequestContext(request))

def getJobDetails(jobID=0):
    job_details = {}
    try:
        jobObj = Job.objects.filter(id=int(jobID))[0]
        job_details = jobObj.getDetails()
        job_details["encoder"] = jobObj.encoder.name
        del job_details["id"]
        del job_details["encoder_id"]
    except IndexError:
        pass
    return job_details

def getJobs(first_id, last_id, search_str=None, sort_by="name", asc=True):
    
    sort_col = "%s"
    if not asc:
        sort_col = "-" + sort_col
    sort_col = sort_col % sort_by
    
    jobs = Job.objects.all().order_by(sort_col)
    
    if search_str:
        total_jobs = len(jobs)
        search_args = Q(name__icontains=search_str)
        
        jobs = jobs.filter(search_args)
        filtered_jobs = len(jobs)
    else:
        total_jobs = filtered_jobs = len(jobs)
    jobs = jobs[first_id:last_id]
    
    job_list = []
    for j in jobs:
        job = [ '<a href=%d>%s</a>' % (j.id, j.name),
            j.description, j.encoder.name,
            j.created_by,
            j.created_on.strftime('%Y-%m-%d %H:%M:%S'),
            j.modified_by, 
            j.modified_on.strftime('%Y-%m-%d %H:%M:%S'),
            j.options, j.extension.name ]
        job_list.append(job)
    return total_jobs, filtered_jobs, job_list

