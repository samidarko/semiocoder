import json
from semiocoder.settings import LOGIN_URL
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponse, HttpResponseRedirect
from django.template.context import RequestContext
from django.shortcuts import render_to_response
from semiocoder.encoder.models import Joblist, Job
from semiocoder.encoder.forms import JoblistForm

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def list(request):
    joblist_list = Joblist.objects.all()
    data = { 'joblist_list' : joblist_list, }
    return render_to_response("encoder/joblist.html", data, context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def details(request, jobId):
    data = { 'element': 'joblist', 'id' : jobId, 'details' : getJoblistDetails(jobId), }
    return render_to_response("encoder/encoding_details.html", data, context_instance=RequestContext(request))

def jobs_data(request, joblistId):
    json_data = json.dumps(getJoblist_data(joblistId))
    return HttpResponse(json_data)

def details_data(request, jobId):
    json_data = json.dumps(getJob_data(jobId))
    return HttpResponse(json_data)

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def form(request, jobId):
    if jobId == '0':
        form = JoblistForm() 
    elif jobId > '0':
        jl = Joblist.objects.get(pk=jobId)
        form = JoblistForm(instance=jl)
    data = { 'element': 'joblist', 'form': form, 'formid': jobId }
    return render_to_response('encoder/encoding_form.html', data, context_instance=RequestContext(request))

def submit(request):
    if request.method == 'POST':
        jobId = int(request.POST["formid"])
        username = request.user.username
        if jobId == 0:
            #jl = Joblist(created_by=username, modified_by=username, created_on=datetime.datetime.now(), modified_on=datetime.datetime.now())
            jl = Joblist(created_by=username, modified_by=username)
            form = JoblistForm(request.POST, instance=jl)
        elif jobId > 0:
            jl = Joblist.objects.get(pk=jobId)
            jl.modified_by=username
            #jl.modified_on=datetime.datetime.now()
            form = JoblistForm(request.POST, instance=jl)
        if form.is_valid(): 
            form.save()
            return HttpResponseRedirect('/joblist')
        else:
            data = { 'element': 'job', 'form': form, 'formid': jobId }
            return render_to_response('encoder/encoding_form.html', data, context_instance=RequestContext(request))    
    else:
        return HttpResponseRedirect('/joblist') 

def delete(request, jobId):
    if request.method == 'POST':
        jobId = int(request.POST["formid"])
        if request.POST["confirm"] == "yes":
            jl = Joblist.objects.get(pk=jobId)
            jl.delete()
        return HttpResponseRedirect('/joblist')
    else:
        jl = Joblist.objects.get(pk=jobId)
        data = { 'element': 'joblist', 'name': jl.name, 'formid': jobId }
        return render_to_response('encoder/delete_confirmation.html', data, context_instance=RequestContext(request))


def getJoblist_data(joblistID):
    joblist = Joblist.objects.filter(id=int(joblistID))
    job_list = joblist[0].job.all() 
    json_job_list = []
    for j in job_list:
        job = {}
        id = "_%d_%d" % (int(joblistID), j.id)
        url = "/job/%d" % (j.id)
        title = '<b>%s</b>' % (j.name)
        job["data"] = { "title" : title, "attr" : { "href" : url } }
        job["attr"] = { "id" : id , "rel" : "job" , "href" : "" , "class" : "hangar-row" }
        job["state"] = "closed"
        json_job_list.append(job)
    return json_job_list

def getJob_data(jobID):
    jobObj = Job.objects.filter(id=int(jobID))[0]
    job = jobObj.getDetails()
    del job["id"]
    del job["name"]
    del job["encoder_id"]
    job["encoder"] = jobObj.encoder.name
    json_job_detail = []
    for k, v in job.items():
        if v is not None:
            job_detail = {}
            job_detail["data"] = '<b>%s</b> : <i>%s</i>' % (k, v)
#        id = "_%d_%d_%d" % (int(joblistID), int(jobID), job["id"])
            job_detail["attr"] = { "rel" : "job_detail" , "href" : "" , "class" : "hangar-row" }
            job_detail["state"] = "closed"
            json_job_detail.append(job_detail)
    return json_job_detail

def getJoblistDetails(jobId=0):
    joblist_details = {}
    try:
        joblist_details = Joblist.objects.filter(id=int(jobId))[0].getDetails()
        del joblist_details["id"]
    except IndexError:
        pass
    return joblist_details

