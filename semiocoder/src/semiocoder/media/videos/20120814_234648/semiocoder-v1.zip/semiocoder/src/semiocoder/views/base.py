from django.db.models import Q
from django.contrib.auth.decorators import user_passes_test
from django.template.context import RequestContext
from django.shortcuts import render_to_response
from semiocoder.encoder.models import Job
from semiocoder.settings import LOGIN_URL

def accueil(request):
    return render_to_response("accueil.html", context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def search(request):
    """
    """
    query = request.GET.get('q', '')
    if query:
        qset = (
            Q(joblist__name__icontains=query) | Q(description__icontains=query)
        )
        results = Job.objects.filter(qset).distinct()
    else:
        results = []

    data =  { "results": results, "query": query }

    return render_to_response("search.html", data, context_instance=RequestContext(request))



def about(request):
    return render_to_response("about.html", context_instance=RequestContext(request))

