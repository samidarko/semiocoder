import os, sys

SEMIOCODER = os.path.dirname(os.path.abspath(os.path.dirname(__file__)))
PARENT = os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(os.path.dirname(__file__)))))
sys.path.append(SEMIOCODER)
sys.path.append(PARENT)

os.environ['DJANGO_SETTINGS_MODULE'] = 'semiocoder.settings'