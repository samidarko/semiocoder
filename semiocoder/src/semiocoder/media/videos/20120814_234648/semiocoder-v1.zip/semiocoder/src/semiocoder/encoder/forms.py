from django import forms
#from django.contrib.admin.widgets import AdminFileWidget
from semiocoder.encoder.models import Joblist, Job, Task

class JoblistForm(forms.ModelForm):
    
    class Meta:
        model = Joblist
        fields = ('name', 'description', 'job')


class JobForm(forms.ModelForm):

    class Meta:
        model = Job
        fields = ('name', 'description', 'encoder', 'options', 'extension')

class TaskForm(forms.ModelForm):
    #NOTIFICATION_CHOICES = ((0,'None'), (1,'User'), (2,'Group'))
    #notification = forms.BooleanField(widget=forms.CheckboxInput(),choices=NOTIFICATION_CHOICES,required=False)
    
    class Meta:
        model = Task
        fields = ('joblist', 'schedule', 'source_file', 'notify')

#class OutputfilesForm(forms.Form):
#    outputfiles = forms.MultipleChoiceField(widget = forms.CheckboxSelectMultiple(), required=False)