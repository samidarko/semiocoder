
$(document).ready(function() {
	$('#task_table').dataTable( {
		"bProcessing": true,
		"bServerSide": true,
		"sAjaxSource": "/task/task_data",
	} );
} );

