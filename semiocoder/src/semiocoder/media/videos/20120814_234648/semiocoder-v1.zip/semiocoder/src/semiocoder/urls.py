from django.conf.urls.defaults import patterns, include
from django.views import static

from semiocoder import settings
from semiocoder.views import base, joblist, job, task, api

# Uncomment the next two lines to enable the admin:
from django.contrib import admin
admin.autodiscover()

urlpatterns = patterns('',

    # Uncomment the admin/doc line below to enable admin documentation:
    #(r'^admin/doc/', include('django.contrib.admindocs.urls')),
    # Uncomment the next line to enable the admin:  
    (r'^admin/', include(admin.site.urls)),
    (r'^%s(?P<path>.*)$' % settings.MEDIA_URL[1:], static.serve, {'document_root' : settings.MEDIA_ROOT}),
 
    (r'^%s$' % settings.LOGIN_URL[1:], 'django.contrib.auth.views.login', {'template_name' : 'registration/login.html'}),
    (r'^%s$' % settings.LOGOUT_URL[1:], 'django.contrib.auth.views.logout', {'next_page' : '/'}),
    (r'^user/change_password$', 'django.contrib.auth.views.password_change', {'template_name' : 'registration/password_change.html', 'post_change_redirect' : '/'}),
    
    (r'^$', base.accueil),
    #Tasks
    (r'^task/$', task.list),
    (r'^task/(\d+)$', task.details),
    (r'^task/task_data$', task.task_data),
    (r'^task/his_data$', task.his_data),
    (r'^task/form/(\d+)$', task.form),
    (r'^task/form$', task.submit),
    (r'^task/delete/(\d+)$', task.delete),
    (r'^task/history/$', task.history),
    (r'^task/output/(\d+_\d+)$', task.output),
    (r'^task/log/(\d+)$', task.log),

    #Joblist
    (r'^joblist/$', joblist.list),
    (r'^joblist/(\d+)$', joblist.details),
    (r'^joblist/json/(\d+)$', joblist.jobs_data),
    (r'^joblist/json/\d+/(\d+)/$', joblist.details_data),
    (r'^joblist/form/(\d+)$', joblist.form),
    (r'^joblist/form$', joblist.submit),
    (r'^joblist/delete/(\d+)$', joblist.delete),
    #Job
    (r'^job/$', job.list),
    (r'^job/(\d+)$', job.details),
    (r'^job/all_data$', job.all_data),
    (r'^job/form/(\d+)$', job.form),
    (r'^job/form$', job.submit),
    (r'^job/delete/(\d+)$', job.delete),
    
    
    #Search
    (r'^search/$', base.search),
    #About
    (r'^about/$', base.about),
    
    #API
    (r'^api$', api.api),
)
