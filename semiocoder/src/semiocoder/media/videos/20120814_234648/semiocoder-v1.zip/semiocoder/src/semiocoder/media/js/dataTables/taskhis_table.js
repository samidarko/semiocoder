
$(document).ready(function() {
	$('#taskhis_table').dataTable( {
		"bProcessing": true,
		"bServerSide": true,
		"sAjaxSource": "/task/his_data",
	} );
} );

