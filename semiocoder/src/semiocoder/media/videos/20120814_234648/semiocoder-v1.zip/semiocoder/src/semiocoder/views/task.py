import os
import json
#import mmpython
from datetime import datetime
from semiocoder.settings import LOGIN_URL
from django.contrib.auth.decorators import user_passes_test
from django.http import HttpResponse, HttpResponseRedirect
from django.template.context import RequestContext
from django.shortcuts import render_to_response
from django.db.models import Q
from semiocoder.encoder.models import Task, TaskHistory
from semiocoder.encoder.forms import TaskForm

taskcol = [
    "joblist",
    "description",
    "schedule",
    "owner",
    "state",
    "source_file",
    "notify",
]

hiscol = [
    "joblist",
    "owner",
    "state",
    "starttime",
    "endtime",
]

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def list(request):
    return render_to_response("encoder/task.html", context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def details(request, taskId):
    data = { 'element': 'task', 'details' : getTaskDetails(taskId), }
    return render_to_response("encoder/encoding_details.html", data, context_instance=RequestContext(request))

def task_data(request):
    
    try:
        iDisplayStart = int(request.GET["iDisplayStart"])
        iDisplayLength = int(request.GET["iDisplayLength"])
        sSearch = request.GET["sSearch"]
        sEcho = int(request.GET["sEcho"])
        try:
            column = int(request.GET["iSortCol_0"])
            ascending = (request.GET["sSortDir_0"] == "asc")
        except:
            column = 0
            ascending = True
    except:
        pass

    total_tasks, filtered_tasks, tasks = getTasks(first_id=iDisplayStart, 
                         last_id=iDisplayStart + iDisplayLength - 1,
                         search_str=sSearch,
                         sort_by=taskcol[column], 
                         asc=ascending)

    json_data = {
        "sEcho" : sEcho,
        "iTotalRecords" : total_tasks,
        "iTotalDisplayRecords" : filtered_tasks,
        "aaData" : tasks
    }

    return HttpResponse(json.dumps(json_data))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def form(request, taskId):
    if taskId == '0':
        form = TaskForm(initial = {"schedule": datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
    elif taskId > '0':
        j = Task.objects.get(pk=taskId)
        form = TaskForm(instance=j)
    data = { 'element': 'task', 'form': form, 'formid': taskId }
    return render_to_response('encoder/encoding_form.html', data, context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def submit(request):
    if request.method == 'POST':
        taskId = int(request.POST["formid"])
        username = request.user.username
        if taskId == 0:
            t = Task(owner=username, state="idle")
            form = TaskForm(request.POST, request.FILES, instance=t)
        elif taskId > 0:
            t = Task.objects.get(pk=taskId)
            t.modified_by = username
            form = TaskForm(request.POST, request.FILES, instance=t)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/task')
        else:
                data = { 'element': 'task', 'form': form, 'formid': taskId }
                return render_to_response('encoder/encoding_form.html', data, context_instance=RequestContext(request))    
    else:
        return HttpResponseRedirect('/task') 

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)   
def delete(request, taskId):
    if request.method == 'POST':
        taskId = int(request.POST["formid"])
        if request.POST["confirm"] == "yes":
            t = Task.objects.get(pk=taskId)
            dir = t.source_file.url[:30].replace("/static", "media")
            t.source_file.delete()
            t.delete()
            os.rmdir(dir)
        return HttpResponseRedirect('/task')
    else:
        t = Task.objects.get(pk=taskId)
        data = { 'element': 'task', 'formid': taskId }
        return render_to_response('encoder/delete_confirmation.html', data, context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def history(request):
    return render_to_response("encoder/task_history.html", context_instance=RequestContext(request))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def his_data(request):
    
    try:
        iDisplayStart = int(request.GET["iDisplayStart"])
        iDisplayLength = int(request.GET["iDisplayLength"])
        sSearch = request.GET["sSearch"]
        sEcho = int(request.GET["sEcho"])
        try:
            column = int(request.GET["iSortCol_0"])
            ascending = (request.GET["sSortDir_0"] == "asc")
        except:
            column = 0
            ascending = True
    except:
        pass

    total_tasks, filtered_tasks, tasks = getHistory(first_id=iDisplayStart, 
                         last_id=iDisplayStart + iDisplayLength - 1,
                         search_str=sSearch,
                         sort_by=hiscol[column], 
                         asc=ascending)

    json_data = {
        "sEcho" : sEcho,
        "iTotalRecords" : total_tasks,
        "iTotalDisplayRecords" : filtered_tasks,
        "aaData" : tasks
    }

    return HttpResponse(json.dumps(json_data))

@user_passes_test(lambda u: u.has_perm('encoder'), login_url=LOGIN_URL)
def output(request, ref):
    try:
        files = os.listdir('media/videos/'+ref)
    except:
        return HttpResponseRedirect('/task/history/')
    if request.method == 'POST':
        selectedfiles = request.POST.getlist('outputfiles')
        #os.chdir('media/videos/'+ref)
        for file in selectedfiles:
            os.remove(file.replace("/static", "media"))
        if len(selectedfiles) == len(files):
            os.rmdir('media/videos/'+ref)
            th = TaskHistory.objects.filter(outputdir=ref)[0]
            th.outputdir = ""
            th.save()
            return HttpResponseRedirect('/task/history/')
        return HttpResponseRedirect('/task/output/'+ref) 
    else:
        th = TaskHistory.objects.filter(outputdir=ref)[0]
        #form.fields["outputfiles"].choices = [('/static/videos/'+ref+'/'+f,"<a href=/static/videos/"+ref+"/"+f+">"+f+"</a>") for f in files]
        data = { 'files': files, 'ref' : ref, 'joblist': th.joblist , 'outputfiles' : files }
        return render_to_response('encoder/output_files.html', data, context_instance=RequestContext(request))
    
def log(request, hid):
    th = TaskHistory.objects.get(pk=hid)
    data = {'joblist': th.joblist , 'log' : th.log.replace("\n", "\n<br>") }
    return render_to_response('encoder/task_log.html', data, context_instance=RequestContext(request))
    

#--------------------------------------------------------------------------------------------------------

def getTaskDetails(taskId):
    #task_details = None
    try:
        taskObj = Task.objects.filter(id=int(taskId))[0]
        task_details = taskObj.getDetails()
        task_details["joblist"] =  taskObj.joblist.name
        task_details["source_file"] = task_details["source_file"][23:]
        del task_details["joblist_id"]
        del task_details["id"]
#        mm = mmpython.parse(taskObj.source_file.path)
#        task_details["mime"] = mm.mime
    except IndexError:
        pass
    return task_details

def getTasks(first_id, last_id, search_str=None, sort_by="name", asc=True):
    
    sort_col = "%s"
    if not asc:
        sort_col = "-" + sort_col
    sort_col = sort_col % sort_by
    
    tasks = Task.objects.order_by(sort_col)
    
    if search_str:
        total_tasks = len(tasks)
        search_args = Q(schedule__icontains=search_str)
        
        tasks = tasks.filter(search_args)
        filtered_tasks = len(tasks)
    else:
        total_tasks = filtered_tasks = len(tasks)
    tasks = tasks[first_id:last_id]
    
    tasks_list = []
    for t in tasks:
        if t.notify == 1: 
            notify = "User"
        elif  t.notify == 2:
            notify = "Group"
        else: 
            notify = "disabled"
        task = [ str(t.joblist),
            t.schedule.strftime('%Y-%m-%d %H:%M:%S'),
            t.owner,
            t.state,
            str(t.source_file)[23:],
            notify,
            '<a href="form/%d"><img src="/static/images/edit.png"></a>' % (t.id),
            '<a href="delete/%d"><img src="/static/images/delete.png"></a>' % (t.id),
             ]
        tasks_list.append(task)
    return total_tasks, filtered_tasks, tasks_list

def getHistory(first_id, last_id, search_str=None, sort_by="name", asc=True):
    
    sort_col = "%s"
    if not asc:
        sort_col = "-" + sort_col
    sort_col = sort_col % sort_by
    
    tasks = TaskHistory.objects.order_by(sort_col)
    
    if search_str:
        total_tasks = len(tasks)
        search_args = Q(schedule__icontains=search_str)
        
        tasks = tasks.filter(search_args)
        filtered_tasks = len(tasks)
    else:
        total_tasks = filtered_tasks = len(tasks)
    tasks = tasks[first_id:last_id]
    
    tasks_list = []
    for t in tasks:
        if t.outputdir:
            outputdir = '<a href="/task/output/%s">output</a>' % (t.outputdir)
        else:
            outputdir = "No Files"
        task = [ t.joblist,
            t.owner, 
            t.state,
            t.starttime.strftime('%Y-%m-%d %H:%M:%S'),
            t.endtime.strftime('%Y-%m-%d %H:%M:%S'),
            outputdir,
            '<a href="/task/log/%d">log</a>' % (t.id),
             ]
        tasks_list.append(task)
    return total_tasks, filtered_tasks, tasks_list
    