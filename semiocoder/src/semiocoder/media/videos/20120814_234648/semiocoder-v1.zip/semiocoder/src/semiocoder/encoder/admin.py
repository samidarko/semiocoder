from django.contrib import admin
from semiocoder.encoder.models import Encoder, Joblist, Job, Extension

class EncoderAdmin(admin.ModelAdmin):
    pass

class JoblistAdmin(admin.ModelAdmin):
    pass

class JobAdmin(admin.ModelAdmin):
    pass

class ExtensionAdmin(admin.ModelAdmin):
    pass

admin.site.register(Encoder, EncoderAdmin)
admin.site.register(Joblist, JoblistAdmin)
admin.site.register(Job, JobAdmin)
admin.site.register(Extension, ExtensionAdmin)
